import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:postest7_1915016009_haniifahfitriani/datapesanan.dart';
import 'DataController.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'PesananController.dart';
import 'TableController.dart';
import 'main.dart';
import 'form.dart';

Widget buildMobil1(BuildContext context) {
  // final urlBurger = "assets/mobil1.png";

  return ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: EdgeInsets.only(top: 25, right: 30, left: 30, bottom: 20),
      color: Color.fromARGB(255, 56, 56, 56),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image.network(urlBurger, width: 260, height: 100, fit: BoxFit.fill),
          Container(
            padding: EdgeInsets.only(top: 20),
            child: Text(
              'Honda Civic',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: 30,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '\Rp. 900.000.000',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20, bottom: 5),
            child: Column(
              children: [
                SizedBox(
                  width: 100.0,
                  height: 40.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetailPage()));
                    },
                    child: Text("Detail"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget buildMobil2(BuildContext context) {
  // final urlBurger = "assets/mobil2.png";

  return ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: EdgeInsets.only(top: 25, right: 30, left: 30, bottom: 20),
      color: Color.fromARGB(255, 56, 56, 56),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image.network(urlBurger, width: 260, height: 100, fit: BoxFit.fill),
          Container(
            padding: EdgeInsets.only(top: 20),
            child: Text(
              'Honda Brio',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: 30,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '\Rp. 155.000.000',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20, bottom: 5),
            child: Column(
              children: [
                SizedBox(
                  width: 100.0,
                  height: 40.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetailPage2()));
                    },
                    child: Text("Detail"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget buildMobil3(BuildContext context) {
  // final urlBurger = "assets/mobil3.png";

  Container(
    width: 260,
    height: 100,
    margin: EdgeInsets.only(top: 5, bottom: 20),
    decoration: BoxDecoration(
      image: DecorationImage(
        image: AssetImage("assets/mobil3.png"),
      ),
    ),
  );
  return ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Container(
      padding: EdgeInsets.only(top: 25, right: 30, left: 30, bottom: 20),
      color: Color.fromARGB(255, 56, 56, 56),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image.network(urlBurger, width: 260, height: 100, fit: BoxFit.fill),
          Container(
            padding: EdgeInsets.only(top: 20),
            child: Text(
              'Honda HR-V',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontSize: 30,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '\Rp. 360.000.000',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20, bottom: 5),
            child: Column(
              children: [
                SizedBox(
                  width: 100.0,
                  height: 40.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DetailPage3()));
                    },
                    child: Text("Detail"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

class showroomcar extends StatelessWidget {
  const showroomcar({Key? key}) : super(key: key);

  get child => null;

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Postest 6 Haniifah Fitriani'),
        backgroundColor: Color.fromARGB(255, 134, 0, 0),
      ),
      backgroundColor: Color.fromARGB(255, 0, 0, 0),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 100, bottom: 15, left: 30, right: 50),
            child: (Text("SHOWROOM MOBIL HONDA",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                  letterSpacing: 2,
                  wordSpacing: 12,
                ))),
          ),
          Container(
            margin: EdgeInsets.only(top: 25, bottom: 20, left: 30, right: 50),
            child: (Text(
                "Kami menyediakan berbagai tipe mobil Honda dengan harga yang terjangkau",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 121, 121, 121),
                ))),
          ),
          Container(
            width: 500,
            height: 350,
            margin: EdgeInsets.only(top: 5, bottom: 20),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/showroom.png"),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 15),
            child: Column(
              children: [
                SizedBox(
                  width: 200.0,
                  height: 50.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => MainPage()));
                    },
                    child: Text("Mulai"),
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white,
                        onPrimary: Color.fromARGB(255, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50))),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MainPage extends StatelessWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        backgroundColor: Color.fromARGB(255, 134, 0, 0),
      ),
      backgroundColor: Color.fromARGB(255, 0, 0, 0),
      drawer: Drawer(
        child: ListView(padding: EdgeInsets.all(0.0), children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text('Haniifah Fitriani'),
            accountEmail: Text('haniifah.fitriani@gmail.com'),
            currentAccountPicture: CircleAvatar(
              backgroundImage: ExactAssetImage('assets/hanii.jpeg'),
            ),
            onDetailsPressed: () {},
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/fundo.jpg'), fit: BoxFit.fill)),
          ),
          ListTile(
            title: Text('Home'),
            leading: Icon(Icons.home),
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => MainPage()));
            },
          ),
          Divider(),
          ListTile(
            title: Text('Data Pesanan'),
            leading: Icon(Icons.wysiwyg),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => DataPesanan()));
            },
          ),
          ListTile(
              title: Text('Tutup'),
              leading: Icon(Icons.close),
              onTap: () {
                Navigator.of(context).pop();
              }),
        ]),
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 50, bottom: 40, left: 30),
            child: (Text("Pilih Mobil Mu!",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                  letterSpacing: 2,
                ))),
          ),
          Center(child: buildMobil1(context)),
          Container(
            margin: EdgeInsets.only(top: 40),
          ),
          Center(child: buildMobil2(context)),
          Container(
            margin: EdgeInsets.only(top: 40),
          ),
          Center(child: buildMobil3(context)),
          Container(
            margin: EdgeInsets.only(bottom: 40),
          ),
        ],
      ),
    );
  }
}

class DetailPage extends StatelessWidget {
  const DetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Detail'),
          backgroundColor: Color.fromARGB(255, 134, 0, 0),
        ),
        backgroundColor: Color.fromARGB(255, 0, 0, 0),
        body: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 30, bottom: 15),
              child: const Center(
                  child: Text("CIVIC Type R 6 Speed M/T",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ))),
            ),
            Container(
              width: 500,
              height: 350,
              margin: EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/mobil1.png"),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          child: InkWell(
            child: Container(
              child: ListView(
                children: [
                  Container(
                      padding: EdgeInsets.only(top: 15),
                      margin: EdgeInsets.all(10),
                      child: Column(children: [
                        Text(
                          'Spesifikasi',
                          style: TextStyle(
                              fontSize: 30,
                              color: Color.fromARGB(255, 0, 0, 0),
                              fontWeight: FontWeight.w600),
                        ),
                      ])),
                  Container(
                    margin: EdgeInsets.all(10),
                    child: Column(children: [
                      Text(
                        '2.0 L VTEC Turbo Engine 310 PS\n6 M/T\n20 Alloy Wheel\n3 Driving Mode with Adaptive Damper System',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 255, 255, 255),
                          fontWeight: FontWeight.w500,
                          height: 2,
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 10),
                    child: Column(
                      children: [
                        SizedBox(
                          width: 200.0,
                          height: 50.0,
                          child: ElevatedButton(
                            onPressed: () => Get.to(() => FormPage()),
                            child: Text("Beli Sekarang"),
                            style: ElevatedButton.styleFrom(
                                primary: Color.fromARGB(255, 0, 0, 0),
                                onPrimary: Color.fromARGB(255, 255, 255, 255),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50))),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50)),
                color: Color.fromARGB(255, 107, 107, 107),
              ),
              height: 350,
            ),
          ),
          color: Colors.transparent,
        ));
  }
}

class DetailPage2 extends StatelessWidget {
  const DetailPage2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Detail'),
          backgroundColor: Color.fromARGB(255, 134, 0, 0),
        ),
        backgroundColor: Color.fromARGB(255, 0, 0, 0),
        body: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 30, bottom: 15),
              child: const Center(
                  child: Text("Honda Brio Satya S M/T",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ))),
            ),
            Container(
              width: 500,
              height: 350,
              margin: EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/mobil2.png"),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          child: InkWell(
            child: Container(
              child: ListView(
                children: [
                  Container(
                      padding: EdgeInsets.only(top: 15),
                      margin: EdgeInsets.all(10),
                      child: Column(children: [
                        Text(
                          'Spesifikasi',
                          style: TextStyle(
                              fontSize: 30,
                              color: Color.fromARGB(255, 0, 0, 0),
                              fontWeight: FontWeight.w600),
                        ),
                      ])),
                  Container(
                    margin: EdgeInsets.all(10),
                    child: Column(children: [
                      Text(
                        '1.2L i-VTEC 90PS\n5M/T\nChrome Front Grille\nHeadlamp with LED Light Guide',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 255, 255, 255),
                          fontWeight: FontWeight.w500,
                          height: 2,
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 10),
                    child: Column(
                      children: [
                        SizedBox(
                          width: 200.0,
                          height: 50.0,
                          child: ElevatedButton(
                            onPressed: () => Get.to(() => FormPage()),
                            child: Text("Beli Sekarang"),
                            style: ElevatedButton.styleFrom(
                                primary: Color.fromARGB(255, 0, 0, 0),
                                onPrimary: Color.fromARGB(255, 255, 255, 255),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50))),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50)),
                color: Color.fromARGB(255, 107, 107, 107),
              ),
              height: 350,
            ),
          ),
          color: Colors.transparent,
        ));
  }
}

class DetailPage3 extends StatelessWidget {
  const DetailPage3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Detail'),
          backgroundColor: Color.fromARGB(255, 134, 0, 0),
        ),
        backgroundColor: Color.fromARGB(255, 0, 0, 0),
        body: ListView(
          children: [
            Container(
              margin: EdgeInsets.only(top: 30, bottom: 15),
              child: const Center(
                  child: Text("HR-V S CVT",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ))),
            ),
            Container(
              width: 500,
              height: 350,
              margin: EdgeInsets.only(top: 5),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/mobil3.png"),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          child: InkWell(
            child: Container(
              child: ListView(
                children: [
                  Container(
                      padding: EdgeInsets.only(top: 15),
                      margin: EdgeInsets.all(10),
                      child: Column(children: [
                        Text(
                          'Spesifikasi',
                          style: TextStyle(
                              fontSize: 30,
                              color: Color.fromARGB(255, 0, 0, 0),
                              fontWeight: FontWeight.w600),
                        ),
                      ])),
                  Container(
                    margin: EdgeInsets.all(10),
                    child: Column(children: [
                      Text(
                        '1.5L DOHC i-VTEC Engine\nHonda Sensing\nFull LED Headlights with LED DRL\n17" Alloy Wheels',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 255, 255, 255),
                          fontWeight: FontWeight.w500,
                          height: 2,
                        ),
                      ),
                    ]),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 10),
                    child: Column(
                      children: [
                        SizedBox(
                          width: 200.0,
                          height: 50.0,
                          child: ElevatedButton(
                            onPressed: () => Get.to(() => FormPage()),
                            child: Text("Beli Sekarang"),
                            style: ElevatedButton.styleFrom(
                                primary: Color.fromARGB(255, 0, 0, 0),
                                onPrimary: Color.fromARGB(255, 255, 255, 255),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(50))),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50),
                    topRight: Radius.circular(50)),
                color: Color.fromARGB(255, 107, 107, 107),
              ),
              height: 350,
            ),
          ),
          color: Colors.transparent,
        ));
  }
}
