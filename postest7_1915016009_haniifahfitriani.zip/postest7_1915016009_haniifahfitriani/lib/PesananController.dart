import 'package:flutter/material.dart';
import 'package:get/get.dart';


class PesananController extends GetxController {
  TextEditingController namaCtrl = TextEditingController();
  TextEditingController alamatCtrl = TextEditingController();
  TextEditingController tipeCtrl = TextEditingController();
  TextEditingController warnaCtrl = TextEditingController();


  @override
  void onClose() {
    namaCtrl.dispose();
    alamatCtrl.dispose();
    tipeCtrl.dispose();
    warnaCtrl.dispose();
    print("Text Controller sudah terhapus");
    super.onClose();
  }
}
