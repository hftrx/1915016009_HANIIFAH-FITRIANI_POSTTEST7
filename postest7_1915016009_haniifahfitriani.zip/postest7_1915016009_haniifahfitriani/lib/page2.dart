import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'DataController.dart';

class DetailPesanan extends StatelessWidget {
  DetailPesanan({Key? key}) : super(key: key);

  final DataController myDataController = Get.find();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detail Pesanan"),
        backgroundColor: Colors.black,
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 40, bottom: 30),
            child: Column(
              children: [
                Text("Detail Data Pesanan",
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    )),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 5, left: 30),
            child: Row(
              children: [
                Text("Nama Pemesan : ${myDataController.nama}",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 17,
                    )),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 15, left: 30),
            child: Row(
              children: [
                Text("Alamat Pemesan : ${myDataController.alamat}",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 17,
                    )),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 15, left: 30),
            child: Row(
              children: [
                Text("Tipe Mobil : ${myDataController.tipeGroup}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontSize: 17,
                    )),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 15, left: 30),
            child: Row(
                            children: [
                Text("Warna Mobil : ${myDataController.warnaGroup}",
                    style: TextStyle(
                      fontSize: 17,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
