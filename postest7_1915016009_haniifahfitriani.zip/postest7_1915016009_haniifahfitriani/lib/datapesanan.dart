import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:postest7_1915016009_haniifahfitriani/page2.dart';
import 'TableController.dart';
import 'DataController.dart';
import 'PesananController.dart';
import 'showroomcar.dart';
import 'form.dart';
import 'main.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/tap_bounce_container.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

class DataPesanan extends StatelessWidget {
  DataPesanan({Key? key}) : super(key: key);

  final TableController fsc = Get.put(TableController());
  final DataController crudController = Get.put(DataController());
  final PesananController pc = Get.put(PesananController());
  @override
  Widget judulKolomTabel(String title) {
    return Text(
      title,
      textAlign: TextAlign.center,
      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
    );
  }

  Widget isiKolomTabel(String isi) {
    return Text(
      isi,
      textAlign: TextAlign.center,
      style: TextStyle(fontSize: 16),
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Pesanan'),
        backgroundColor: Color.fromARGB(255, 134, 0, 0),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Flexible(
            child: StreamBuilder(
              stream:
                  FirebaseFirestore.instance.collection("pesanan").snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                    itemCount: snapshot.data?.docs.length,
                    itemBuilder: (context, i) {
                      QueryDocumentSnapshot<Object?>? hasilData =
                          snapshot.data?.docs[i];
                      return Column(
                        children: [
                          Table(
                            border: TableBorder.lerp(
                              TableBorder(
                                top: BorderSide(width: 2, color: Colors.black),
                              ),
                              TableBorder(
                                bottom: BorderSide(
                                    width: 2,
                                    color: Color.fromARGB(255, 0, 0, 0)),
                              ),
                              0.5,
                            ),
                            children: [
                              TableRow(children: [
                                judulKolomTabel("Nama Pemesan"),
                                judulKolomTabel("Alamat Pemesan"),
                                judulKolomTabel("Tipe\nMobil"),
                                judulKolomTabel("Warna\nMobil"),
                                judulKolomTabel("Aksi"),
                              ]),
                              TableRow(children: [
                                isiKolomTabel(hasilData!['Nama']),
                                isiKolomTabel(hasilData['Alamat']),
                                isiKolomTabel(hasilData['Tipe']),
                                isiKolomTabel(hasilData['Warna']),
                                ElevatedButton(
                                  style: TextButton.styleFrom(
                                    backgroundColor:
                                        Color.fromARGB(255, 255, 0, 0),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (_) => CustomAlert(
                                        id: hasilData.id,
                                      ),
                                    );
                                  },
                                  child: Icon(
                                    Icons.delete,
                                    color: Colors.white,
                                    size: 12,
                                  ),
                                ),
                              ])
                            ],
                          ),
                        ],
                      );
                    },
                  );
                } else {
                  return Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Color.fromARGB(255, 0, 255, 149),
                      ),
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}

class CustomAlert extends StatelessWidget {
  const CustomAlert({
    Key? key,
    required this.id,
  }) : super(key: key);

  final String id;

  @override
  Widget build(BuildContext context) {
    TableController fsc = Get.find();
    return AlertDialog(
      title: const Text('Hapus Data'),
      content: const Text('Data akan dihapus secara PERMANEN'),
      actions: <Widget>[
        TextButton(
          onPressed: () => Get.back(),
          child: const Text('Batal'),
        ),
        TextButton(
          onPressed: () {
            // Queary untuk delete
            fsc.pesanan.value.doc(id).delete();
            showTopSnackBar(
              context,
              CustomSnackBar.error(
                message: "Data Pembeli Berhasil Dihapus",
              ),
            );
            Get.back();
          },
          child: const Text(
            'Hapus',
            style: TextStyle(color: Colors.red),
          ),
        ),
      ],
    );
  }
}
