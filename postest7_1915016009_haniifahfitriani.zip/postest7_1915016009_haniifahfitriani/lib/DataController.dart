import 'package:get/get.dart';

class DataController extends GetxController {
  var switchValue = false.obs;
  var id = "".obs;
  var alamat = "".obs;
  var nama = "".obs;
  var warnaGroup = "".obs;
  pilih_warna(var warna_mobil) {
    warnaGroup.value = warna_mobil;
  }

  var tipeGroup = "".obs;
  pilih_tipe(var tipe_mobil) {
    tipeGroup.value = tipe_mobil;
  }

}
