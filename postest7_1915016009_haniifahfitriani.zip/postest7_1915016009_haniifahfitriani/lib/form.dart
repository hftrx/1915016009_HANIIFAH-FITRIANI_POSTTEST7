import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:postest7_1915016009_haniifahfitriani/datapesanan.dart';
import 'DataController.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'PesananController.dart';
import 'TableController.dart';
import 'main.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/tap_bounce_container.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

class FormPage extends StatelessWidget {
  FormPage({Key? key, this.isUpdate = false}) : super(key: key);

  PesananController pc = Get.put(PesananController());
  TableController fsc = Get.put(TableController());
  final DataController crudController = Get.put(DataController());

  bool isUpdate;
  bool isYakin = false;

  @override
  Widget build(BuildContext context) {
    if (isUpdate) {
      // Lanjutan dari onTap di Home.dart
      pc.namaCtrl.text = crudController.nama.value;
      pc.alamatCtrl.text = crudController.alamat.value;
      pc.tipeCtrl.text = crudController.tipeGroup.value;
      pc.warnaCtrl.text = crudController.warnaGroup.value;
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(" Form ${this.isUpdate ? 'Update' : 'Tambah'} Pesanan"),
        backgroundColor: Colors.black,
      ),
      body: ListView(
        children: [
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 40, bottom: 40),
                child: const Center(
                    child: Text("Form Pemesanan Mobil Honda",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ))),
              ),
              Container(
                margin: EdgeInsets.only(right: 40, left: 40),
                child: Column(
                  children: [
                    TextField(
                      controller: pc.namaCtrl,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Isi Nama Legkap",
                          labelText: "Nama Pembeli"),
                    ),
                    SizedBox(height: 30),
                    TextFormField(
                      controller: pc.alamatCtrl,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Isi Alamat Lengkap",
                          labelText: "Alamat"),
                    ),
                    SizedBox(height: 30),
                    Container(
                      margin: EdgeInsets.only(top: 40, bottom: 30),
                      child: Column(
                        children: [
                          Text("Pilih Tipe Mobil",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              )),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 10),
                child: Column(
                  children: [
                    ListTile(
                        title: Text("Honda Jazz"),
                        leading: Obx(
                          () => Radio(
                            value: "Honda Jazz",
                            groupValue: crudController.tipeGroup.value,
                            onChanged: (value) {
                              crudController.pilih_tipe(value);
                            },
                          ),
                        )),
                    ListTile(
                        title: Text("Honda Brio"),
                        leading: Obx(
                          () => Radio(
                            value: "Honda Brio",
                            groupValue: crudController.tipeGroup.value,
                            onChanged: (value) {
                              crudController.pilih_tipe(value);
                            },
                          ),
                        )),
                    ListTile(
                      title: Text("Honda Civic"),
                      leading: Obx(
                        () => Radio(
                          value: "Honda Civic",
                          groupValue: crudController.tipeGroup.value,
                          onChanged: (value) {
                            crudController.pilih_tipe(value);
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 30, bottom: 30),
                child: Column(
                  children: [
                    Text("Pilih Warna Mobil",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 10),
                child: Column(
                  children: [
                    ListTile(
                      title: Text("Merah"),
                      leading: Obx(
                        () => Radio(
                          value: "Merah",
                          groupValue: crudController.warnaGroup.value,
                          onChanged: (value) {
                            crudController.pilih_warna(value);
                          },
                        ),
                      ),
                    ),
                    ListTile(
                      title: Text("Hitam"),
                      leading: Obx(
                        () => Radio(
                          value: "Hitam",
                          groupValue: crudController.warnaGroup.value,
                          onChanged: (value) {
                            crudController.pilih_warna(value);
                          },
                        ),
                      ),
                    ),
                    ListTile(
                      title: Text("Putih"),
                      leading: Obx(
                        () => Radio(
                          value: "Putih",
                          groupValue: crudController.warnaGroup.value,
                          onChanged: (value) {
                            crudController.pilih_warna(value);
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 55, bottom: 10),
                child: Column(
                  children: [
                    Text(
                        "Jika data diatas sudah benar.\nSilahkan klik tombol dibawah",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        )),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20, bottom: 20),
                child: Column(
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        if (this.isUpdate) {
                          // Query untuk update
                          fsc.pesanan.value
                              .doc(crudController.id.value)
                              .update({
                            'Nama': pc.namaCtrl.text,
                            'Alamat': pc.alamatCtrl.text,
                            'Tipe Mobil': "${crudController.tipeGroup.value}",
                            'Warna Mobil': "${crudController.warnaGroup.value}",
                          });
                        } else {
                          // Query untuk create
                          fsc.pesanan.value.add({
                            'Nama': pc.namaCtrl.text,
                            'Alamat': pc.alamatCtrl.text,
                            'Tipe': "${crudController.tipeGroup.value}",
                            'Warna': "${crudController.warnaGroup.value}",
                          });
                        }
                        FocusScope.of(context).unfocus();
                        if (isUpdate) {
                          showTopSnackBar(
                            context,
                            CustomSnackBar.info(
                              message: "Data Pembeli berhasil Diupdate Silahkan Lihat Di Data Pesanan",
                            ),
                          );
                        } else {
                          showTopSnackBar(
                            context,
                            CustomSnackBar.success(
                              message: "Data Pembeli Berhasil Ditambahkan\nke Data Pesanan",
                            ),
                          );
                          Get.to(
                        DataPesanan(),
                      );
                        }
                      },
                      child: Text(
                          this.isUpdate ? 'Update Pesanan' : 'Tambah Pesanan'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
