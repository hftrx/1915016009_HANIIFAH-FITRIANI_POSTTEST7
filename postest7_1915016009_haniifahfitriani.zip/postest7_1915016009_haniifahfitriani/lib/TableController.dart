import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TableController extends GetxController {
  var pesanan = FirebaseFirestore.instance.collection("pesanan").obs;
}