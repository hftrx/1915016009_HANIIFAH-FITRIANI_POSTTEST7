package com.example.postest7_1915016009_haniifahfitriani

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
